PATO — A Branching-Dialogue Job Interview Simulator Web Application with an Automated Communication-Score Portal for BSIT Alumni of 2025–2026 at Pateros Technological College

OVERVIEW
PATO preserves your existing Node.js + Google Workspace OAuth architecture, administrator login, assets, and direct question-selection flow while upgrading the entire system into an adaptive, voice-driven BSIT interview and learning portal.

HOW TO RUN
1. Install Node.js LTS (v18+).
2. Extract PATO-upgraded.zip and open the folder in VS Code.
3. Dependencies in node_modules/ are already included (or run `npm install` if needed).
4. Optional: Copy `.env.example` to `.env` and add `GEMINI_API_KEY` for live Gemini LLM evaluation (if omitted, PATO automatically runs its deterministic Semantic Rubric & Concept Detection Engine).
5. Run: `npm start`
6. Open http://localhost:3000 in Chrome or Microsoft Edge (recommended for Web Speech API TTS + Speech-to-Text).

LOGIN CREDENTIALS
- BSIT Students & Alumni: Continue with Google using a verified @paterostechnologicalcollege.edu.ph Google Workspace account.
- Administrator Portal: admin@pato.test / admin123 (now verified server-side with HttpOnly session cookies).

KEY UPGRADED CAPABILITIES
1. Voice-Driven Interview Sequence: Mandatory Mic Test (permission, live audio meter, test clip recording & playback) -> Start -> 3-2-1 Countdown -> Duck TTS Speaks Question (replay, mute, speed control, 6 avatar states) -> Manual Voice Recording -> Stop -> Transcript Review -> AI/Semantic Rubric Evaluation -> Adaptive Follow-Up.
2. Adaptive Branching Dialogue: Classifies responses into strong, incomplete, keyword-only, incorrect, vague, irrelevant, or unassessable and tracks explained, mentioned, missing, and misunderstood concepts.
3. Explainable Technical & Behavioral Rubrics: 0–5 criterion scale with exact weights, transcript evidence, strengths, missing concepts, actionable feedback, and non-graded observational audio delivery metrics.
4. Unique Learning Modules: Interview DNA, Branch Trace, Answer Blueprint Coach (Technical & STAR), 3-Level Duck Hint Ladder, Scenario Shift Labs, Answer Evolution (retry & rubric comparison), and Mastery-Unlocked Competency Skill Tree.
5. BSIT Learning Hub & Modes: Practice, Challenge, and Assessment modes across 8 BSIT domains plus structured lessons with spoken tasks.
6. Gamification & Duck Wardrobe: Separate XP/Levels, Coins (cosmetics only), Achievements, and persistent Duck Wardrobe customization with anti-duplicate reward protection.
7. Protected Admin Portal: Manage questions, concepts, misconceptions, lessons, rubric weights, reward rules, and student analytics.
