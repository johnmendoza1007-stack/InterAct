# InterAct Prototype

InterAct is a Node.js web prototype for a job-interview practice and communication-scoring portal for BSIT alumni at Pateros Technological College. It includes Google Workspace sign-in, interview practice, adaptive follow-up questions, rubric scoring, an admin portal, and profile features.

## Project structure

```text
.
├── app.js                     # Browser-side application logic
├── server.js                  # Node.js/Express-style backend
├── index.html                 # Main application page
├── style.css                  # Core styles
├── dashboard-accents.css      # Dashboard styling
├── login-enhancements.css     # Sign-in styling
├── interview-flow.css         # Interview interface styling
├── profile.css                # Profile styling
├── interview-flow.js          # Interview flow logic
├── pato-3d.js                 # 3D/interface effects
├── pato-menu-icons.js         # Menu icon logic
├── sidebar-controls.js         # Sidebar controls
├── assets/                    # Images and static assets
├── data/                      # Runtime data directory
├── profile-update-kit/        # Profile update utilities
├── .env.example               # Environment-variable template
├── .gitignore                 # Files Git should ignore
├── package.json               # Project metadata and dependencies
└── package-lock.json          # Dependency lock file
```

## Requirements

- Node.js 18 or newer
- npm

## Setup

1. Install dependencies:

```bash
npm install
```

2. Create your local environment file:

```bash
cp .env.example .env
```

3. Open `.env` and replace the placeholder values with your own Google OAuth client ID, administrator email/password, and optional Gemini API key.

4. Start the application:

```bash
npm start
```

5. Open the app in your browser:

```text
http://localhost:3000
```

## Security notes

- Do **not** commit `.env`, API keys, passwords, or real user/account data.
- `data/accounts.json` is ignored by Git because it can contain runtime account information.
- The original prototype included a Google OAuth client ID and sample administrator credentials. Replace these with your own credentials before deploying.
- `node_modules/` is intentionally excluded from this repository archive; recreate it with `npm install`.

## GitHub upload

1. Create a new repository on GitHub.
2. Upload the contents of this folder—not the parent ZIP file.
3. Ensure `.env`, `node_modules/`, and `data/accounts.json` are not included.
4. Add a descriptive commit message, such as `Initial InterAct prototype upload`.
