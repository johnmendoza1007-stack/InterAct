Account database is created here automatically.
