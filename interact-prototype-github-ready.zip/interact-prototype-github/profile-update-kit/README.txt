Optional targeted updater for a NEWER local copy of PATO

Use this instead of replacing your project with the full archive if you already have newer dashboard designs or readability fixes.

From this folder run:
  node install-profile-update.js "/path/to/your/current/PATO-upgraded"

Back up your project first. Expected app/server integration points are validated before files are touched. Backups of modified files are created in a timestamped subfolder. app.js, server.js and index.html are updated; profile.css is added. The original account data, .env, existing styles and other files are preserved. Restart the server and hard-refresh afterwards.

If integration points differ, the updater refuses installation rather than guessing. If already installed, it refuses duplication. Read PROFILE-UPDATE-NOTES.txt in the full archive for features, email identity policy, limits and testing.
